import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpService } from '../../shared/services/http.service';
import { id } from '@swimlane/ngx-datatable/release/utils';

@Component({
  selector: 'app-view-customer',
  templateUrl: './view-customer.component.html',
  styleUrls: ['./view-customer.component.scss']
})
export class ViewCustomerComponent implements OnInit {
  public _parameters: any;
  public _id: any;
  public data: any;
  constructor(private _activatedRoute: ActivatedRoute, private _httpService: HttpService) { }

  ngOnInit() {
    this._parameters = this._activatedRoute.params.subscribe(params => {
      if (typeof params['id'] !== 'undefined') {
        this._id = params['id']
      }
    });
    this.loadData();
  }
  private loadData(): any {
    this._httpService.get('clients/show').subscribe(
      result => {
        if (result.response.response_status.response_code === 200) {
          console.log(result.response.data);
          this.data = result.response.data;
          this.data = this.data.filter((rec => {
            return Number(rec.id) === Number(this._id);
          }));
          this.data = this.data[0];
        } else {
        }
      },
      error => {
      },
      complete => {
      }
    );
  }
}
