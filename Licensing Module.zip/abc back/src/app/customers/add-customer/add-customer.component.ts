import { HttpService } from 'src/app/shared/services/http.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { countries } from '../../pages/dashboard/dashboard.data';
import { RbacService } from 'src/app/shared/services/rbac.service';

@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.scss']
})
export class AddCustomerComponent implements OnInit {

  @Input() title;
  @Input() formData;
  public loading = false;
  public hasErrors = false;
  public errorMessages;
  public form: FormGroup;
  public countries;
  permissions: any[];
  roles: any [];
  role: any;
 
  constructor(
    public activeModal: NgbActiveModal,
    public fb: FormBuilder,
    private _httpService: HttpService,
    private rbacService: RbacService,
    public toastrService: ToastrService) { }
  ngOnInit() {
    this.loadCountries();
    this.rbacService
    this.form = this.fb.group({
      name: [this.formData ? this.formData.name : '', Validators.compose([Validators.required])],
      country_id: [this.formData ? this.formData.country_id : '', Validators.compose([Validators.required])],
      client_email: [this.formData ? this.formData.client_email : '', Validators.compose([Validators.required])],
      project_manager_email: [this.formData ? this.formData.project_manager_email : '', Validators.compose([Validators.required])],
      technical_lead_email: [this.formData ? this.formData.technical_lead_email : '', Validators.compose([Validators.required])]
    });
  }
  public submitData(): void {
    this.loading = true;
    this._httpService.post('clients/create', this.form.value).subscribe(
      result => {
        if (result.response.response_status.response_code === 201) {
          this.toastrService.success('Record created successfully!', 'Created Successfully!');
          this.activeModal.close('success');
        } else {
          this._httpService.handleErrorsFromServer(result);
        }
      },
      error => {
        this.errorMessages = error.error.error_messages;
      },
      complete => {
        this.loading = false;
      }

    );
  }
  public saveChanges(): void {
    this.loading = true;
    this.form.value.id = this.formData.id;
    this._httpService.post('clients/update', this.form.value).subscribe(
      result => {
        if (result.response.response_status.response_code === 200) {
          this.toastrService.success('Changes saved!', 'Saved Successfully!');
          this.activeModal.close('success');
        } else {
          this._httpService.handleErrorsFromServer(result);
        }
      },
      error => {
        this.errorMessages = error.error.error_messages;
      },
      complete => {
        this.loading = false;
      }

    );
  }
  
  public closeModal(): void {
    this.activeModal.dismiss('Cross click');
  }
 private loadCountries() {
  this._httpService.get('countries/show').subscribe(
    result => {
      if (result.response.response_status.response_code === 200) {
        this.countries = result.response.data;
      } else {
      }
    },
    error => {
    },
    complete => {
    }
  );
 }
}
