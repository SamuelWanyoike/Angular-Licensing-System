import { NgModule } from '@angular/core';
import { ModalModule } from 'ngx-bootstrap/modal';
import { SharedModule } from '../shared/shared.module';
import { CustomersRoutingModule } from './customers-routing';

@NgModule({
  imports: [
    SharedModule,
    CustomersRoutingModule,
    ModalModule.forRoot(),
    
  ],
  declarations: [
    // ClientsListComponent,
    // AddClientComponent,
   
  ],
  entryComponents: [
    // AddClientComponent,
   
  ],
})
export class CustomersModule { }

