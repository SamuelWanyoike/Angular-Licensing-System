import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ViewCustomerComponent } from './view-customer/view-customer.component';
import { CustomersListComponent } from './customers-list/customers-list.component';


const routes: Routes = [
    {
        path: 'list',
        component: CustomersListComponent,
        data: {
            title: 'Clients List',
        },
        
    
    },
    {
        path: ':id',
        component: ViewCustomerComponent,
        data: {
            breadcrumb: 'View Client',
            title: 'Client'
        }
    },
];

export const CustomersRoutingModule: ModuleWithProviders = RouterModule.forChild(routes);
