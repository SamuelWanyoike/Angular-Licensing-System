import { Component, OnInit, Input } from '@angular/core';
import { HttpService } from 'src/app/shared/services/http.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-add-role',
  templateUrl: './add-role.component.html',
  styleUrls: ['./add-role.component.scss']
})
export class AddRoleComponent implements OnInit {

  @Input() formData;
  public loading = false;
  public hasErrors = false;
  public errorMessages;
  public form: FormGroup;

  constructor(private _httpService: HttpService,
    public toastrService: ToastrService, public activeModal: NgbActiveModal,
    public fb: FormBuilder,) { }

  ngOnInit() {
    this.form = this.fb.group({
      name: [this.formData ? this.formData.name : '', Validators.compose([Validators.nullValidator])],
      description: [this.formData ? this.formData.description : '', Validators.compose([Validators.nullValidator])],
    });
  }

  public submitData(): void {
    this.loading = true;
    this._httpService.post('roles/create', this.form.value).subscribe(
      result => {
        if (result.response.response_status.response_code === 201) {
          this.toastrService.success('Record created successfully!', 'Created Successfully!');
          this.activeModal.close('success');
        } else {
          this.errorMessages = this._httpService.handleErrorsFromServer(result.response.error);
        }
      },
      error => {
        this.errorMessages = error.error.error_messages;
      },
      complete => {
        this.loading = false;
      }

    );
  }
  public saveChanges(): void {
    this.loading = true;
    this.form.value.id = this.formData.id;
    this._httpService.post('roles/update', this.form.value).subscribe(
      result => {
        if (result.response.response_status.response_code === 200) {
          this.toastrService.success('Changes saved!', 'Saved Successfully!');
          this.activeModal.close('success');
        } else {
          this.errorMessages = this._httpService.handleErrorsFromServer(result.errors);
        }
      },
      error => {
       },
      complete => {
        this.loading = false;
      }

    );
  }
  public closeModal(): void {
    this.activeModal.dismiss('Cross click');
  }

 
}
