import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddRoleComponent } from './roles/manage-roles/add-role/add-role.component';
import { ListRolesComponent } from './roles/manage-roles/list-roles/list-roles.component';
import { ListPermissionsComponent } from './permissions/manage-permissions/list-permissions/list-permissions.component';
import { ListRolePermissionComponent } from './roles/manage-roles/list-role-permission/list-role-permission.component';


const routes: Routes = [
    {
        path: 'list',
       component: ListRolesComponent,
        data: {
            title: 'Rbac Module'
        }
    },
    {
        path: 'perm',
       component: ListPermissionsComponent,
        data: {
            title: 'Rbac Module'
        }
    },
    {
        path: 'rp',
       component: ListRolePermissionComponent,
        data: {
            title: 'Rbac Module'
        }
    }
];

export const RbacRoutingModule: ModuleWithProviders = RouterModule.forChild(routes);
