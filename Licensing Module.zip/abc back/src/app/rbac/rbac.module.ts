import { NgModule } from '@angular/core';
import { ModalModule } from 'ngx-bootstrap/modal';
import { SharedModule } from '../shared/shared.module';

import { RbacRoutingModule } from './rbac-routing';
import { AddRoleComponent } from './roles/manage-roles/add-role/add-role.component';
import { ListRolesComponent } from './roles/manage-roles/list-roles/list-roles.component';
import { ListPermissionsComponent } from './permissions/manage-permissions/list-permissions/list-permissions.component';
import { AddPermissionComponent } from './permissions/manage-permissions/add-permission/add-permission.component';
import { ListRolePermissionComponent } from './roles/manage-roles/list-role-permission/list-role-permission.component';
import { AddRolePermissionComponent } from './roles/manage-roles/add-role-permission/add-role-permission.component';



@NgModule({
  imports: [
    SharedModule,
    RbacRoutingModule,
    ModalModule.forRoot(),
  ],
  declarations: [
  AddRoleComponent,
  ListRolesComponent,
  ListPermissionsComponent,
  AddPermissionComponent,
  ListRolePermissionComponent,
  AddRolePermissionComponent],
  entryComponents: [
    AddRoleComponent,
    AddPermissionComponent,
    ListRolePermissionComponent,
    AddRolePermissionComponent
  ],
})
export class RbacModule { }

