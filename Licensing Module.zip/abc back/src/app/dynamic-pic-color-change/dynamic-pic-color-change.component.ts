import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dynamic-pic-color-change',
  templateUrl: './dynamic-pic-color-change.component.html',
  styleUrls: ['./dynamic-pic-color-change.component.scss']
})
export class DynamicPicColorChangeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
