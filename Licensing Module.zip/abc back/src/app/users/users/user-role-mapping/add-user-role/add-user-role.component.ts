import { HttpService } from 'src/app/shared/services/http.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-add-user-role',
  templateUrl: './add-user-role.component.html',
  styleUrls: ['./add-user-role.component.scss']
})
export class AddUserRoleComponent implements OnInit {

  @Input() title;
  @Input() formData;
  @Input() UsersModuleData: any;
  public loading = false;
  public hasErrors = false;
  public errorMessages;
  public form: FormGroup;

  roles: any;
  users: any;
  id: any;
  user_id: number;
  role_id:any;
  constructor(
    public activeModal: NgbActiveModal,
    public fb: FormBuilder,
    private _httpService: HttpService,
    public toastrService: ToastrService) { }
  ngOnInit() {
    this.loadRoles();
    this.loadUsers();
    this.form = this.fb.group({
      user_id: [this.formData ? this.formData.user_id : '', Validators.compose([Validators.required])],
      role_id: [this.formData ? this.formData.role_id : '', Validators.compose([Validators.required])]
    });
  }

  public submitData(): void {
    // this.id = this.form.value;
    // this.role_id = this.loadRoles().role_id; console.log(this.role_id)
    // this.user_id = this.loadUsers().user_id;
    this.loading = true;
    this.id = this.form.value.role_id;
    console.log(this.role_id)
    this._httpService.post('user/role/mapping/create', this.form.value).subscribe(
      result => {
        if (result.response.response_status.response_code === 201) {
          this.toastrService.success('Record created successfully!', 'Created Successfully!');
          this.activeModal.close('success');
        } else {
          this._httpService.handleErrorsFromServer(result);
        }
      },
      
      error => {
        this.errorMessages = error.error.error_messages;
      },
      complete => {
        this.loading = false;
      },
     

    );
  }
  public saveChanges(): void {
    this.loading = true;
    this.form.value.id = this.formData.id;
    this._httpService.post('user/role/mapping/update', this.form.value).subscribe(
      result => {
        if (result.response.response_status.response_code === 200) {
          this.toastrService.success('Changes saved!', 'Saved Successfully!');
          this.activeModal.close('success');
        } else {
          this._httpService.handleErrorsFromServer(result);
        }
      },
      error => {
        this.errorMessages = error.error.error_messages;
      },
      complete => {
        this.loading = false;
      }

    );
  }
  

  public closeModal(): void {
    this.activeModal.dismiss('Cross click');
  }
  
  private loadUsers(): any {
    this._httpService.get('users/list').subscribe(
      result => {
        if (result.response.response_status.response_code === 200) {
          this.users = result.response.data;
        } else {
        }
      },
      error => {
      },
      complete => {
      }
    );
  }

  private loadRoles(): any {
    this._httpService.get('roles/show').subscribe(
      result => {
        if (result.response.response_status.response_code === 200) {
          this.roles = result.response.data;
        } else {
        }
      },
      error => {
      },
      complete => {
      }
    );
  }

}
