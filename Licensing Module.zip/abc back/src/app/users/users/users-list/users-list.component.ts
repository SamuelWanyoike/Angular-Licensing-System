import { CreateUserComponent } from './../create-user/create-user.component';
import { DatePipe } from '@angular/common';
import { HttpService } from 'src/app/shared/services/http.service';
import { Component, OnInit, Input } from '@angular/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { ViewUserComponent } from '../view-user/view-user.component';
import { LabelActiveComponent } from './../../../shared/components/label-active/label-active.component';

@Component({
  selector: 'app-users-list',
  templateUrl: './users-list.component.html',
  styleUrls: ['./users-list.component.scss'],
  providers: [DatePipe]
})
export class UsersListComponent implements OnInit {
  @Input() data;
  public formData;
  public modalRef: NgbModalRef;
  public settings = {
    selectMode: 'single',  // single|multi
    hideHeader: false,
    hideSubHeader: false,
    actions: {
      columnTitle: 'Actions',
      add: false,
      edit: false,
      delete: false,
      custom: [
      //  { name: 'viewrecord', title: '<i class="fa fa-eye"></i>' },
        { name: 'editrecord', title: '&nbsp;&nbsp;<i class="fa  fa-pencil"></i>' }
      ],
      position: 'right'
    },
    delete: {
      deleteButtonContent: '&nbsp;&nbsp;<i class="fa fa-trash-o text-danger"></i>',
      confirmDelete: true
    },
    noDataMessage: 'No data found',
    columns: {
      // username: {
      //   title: 'Username',
      //   type: 'string'
      // },
      email: {
        title: 'Email Address',
        type: 'string'
      },
      created_on: {
        title: 'Created On',
        type: 'string',
      },
      last_login_date: {
        title: 'Last Login',
        type: 'string',
      },
      last_password_change_date: {
        title: 'Last Password Change',
        type: 'string',
      },
      account_status: {
        title: 'Status',
        type: 'custom',
        renderComponent: LabelActiveComponent
      },
    },
    pager: {
      display: true,
      perPage: 10
    }
  };
  dataSet: any;
  constructor(private _httpService: HttpService, private modalService: NgbModal,
    public datePipe: DatePipe, public toastrService: ToastrService) { }
  ngOnInit() {
    this.loadData();
  }
  private loadData(): any {
    this._httpService.get('users/list').subscribe(
      result => {
        if (result.response.response_status.response_code === 200) {
          this.dataSet = result.response.data;
        } else {
        }
      },
      error => {
      },
      complete => {
      }
    );
  }
  public openModal(parentData: any) {
    this.modalRef = this.modalService.open(CreateUserComponent);
    this.modalRef.componentInstance.title = 'Add User';
    this.modalRef.componentInstance.parentData = '';
    this.modalRef.result.then((result) => {
      if (result === 'success') {
        this.loadData();
      }
    }, (reason) => {
    });
  }
  public editRecord(formData: any) {
    this.modalRef = this.modalService.open(CreateUserComponent);
    this.modalRef.componentInstance.formData = formData;
    this.modalRef.componentInstance.title = 'Edit User: ' + formData.email;
    this.modalRef.result.then((result) => {
      if (result === 'success') {
        this.loadData();
      }
    }, (reason) => {
    });
  }
  public onDeleteConfirm(event): void {
    if (window.confirm('Are you sure you want to delete?')) {
      this._httpService.delete('profile/' + event.data.id).subscribe(
        result => {
          if (result.response_code === 200) {
            event.confirm.resolve();
            this.toastrService.success(event.data.id, 'Deleted!');
          } else {
            this.toastrService.error(event.data.id, 'Failed to Delete!');
          }
        }
      );
    } else {
      event.confirm.reject();
    }
  }
  public viewRecord(formData: any) {
    this.modalRef = this.modalService.open(ViewUserComponent);
    this.modalRef.componentInstance.formData = formData;
    this.modalRef.result.then((result) => {
      if (result === 'success') {
      }
    }, (reason) => {
    });
  }

  onCustomAction(event) {
    switch (event.action) {
      case 'viewrecord':
        this.viewRecord(event.data);
        break;
      case 'editrecord':
        this.editRecord(event.data);
    }
  }
}
