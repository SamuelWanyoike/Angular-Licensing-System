import { IMultiSelectSettings, IMultiSelectTexts, IMultiSelectOption } from 'angular-2-dropdown-multiselect';
import { HttpService } from 'src/app/shared/services/http.service';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { Component, OnInit, Input } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.scss']
})
export class CreateUserComponent implements OnInit {
  @Input() title;
  @Input() formData;
  public loading = false;
  public hasErrors = false;
  public errorMessages;
  public form: FormGroup;
  public assignedProfilesModel: number[] = [];
  public thirdControlSettings: IMultiSelectSettings = {
      enableSearch: true,
      checkedStyle: 'checkboxes',
      buttonClasses: 'btn btn-secondary btn-block',
      dynamicTitleMaxItems: 3,
      displayAllSelectedText: true,
      showCheckAll: true,
      showUncheckAll: true
  };
  public thirdControlTexts: IMultiSelectTexts = {
      checkAll: 'Select all',
      uncheckAll: 'Unselect all',
      checked: 'item selected',
      checkedPlural: 'items selected',
      searchPlaceholder: 'Find...',
      defaultTitle: 'Select Item(s)',
      allSelected: 'All selected',
  };
  public profiles: IMultiSelectOption[] = [];
  constructor(
    public activeModal: NgbActiveModal,
    public fb: FormBuilder,
    private _httpService: HttpService,
    public toastrService: ToastrService) { }
  ngOnInit() {
  //  this.loadProfiles();
    this.form = this.fb.group({
      email: [this.formData ? this.formData.email : '', [Validators.required, Validators.email]],
      // first_name: [this.formData ? this.formData.first_name : '', [Validators.nullValidator]],
      // middle_name: [this.formData ? this.formData.middle_name : '', [Validators.nullValidator]],
      // surname: [this.formData ? this.formData.surname : '', [Validators.nullValidator]],
      // profiles: [this.formData ? this.formData.profiles : '', [Validators.nullValidator]],
      // username: [this.formData ? this.formData.username : '', [Validators.required]],
      password: ['', [Validators.required]],
      account_status: [0, [Validators.required]]
    });
    if (this.formData){
    this.form.removeControl('password');
    } else {
      this.form.removeControl('account_status');
    }
  }
  public loadProfiles(): void {
    this._httpService.get('profiles').subscribe(
      result => {
        if (result.response_code === 200) {
          this.profiles = result.data;
          this.profiles = result.data.map(obj => {
           obj.name = obj.profile_name;
            return obj;
          });
        }
      }
    );
  }
  public submitData(): void {
    if (this.formData) {
      this.saveChanges();
    } else {
      this.createRecord();
    }
    this.loading = true;
  }
  private createRecord(): any {
    this._httpService.post('users/register', this.form.value).subscribe(
      result => {
        if (result.response.response_status.response_code === 201) {
          this.toastrService.success('Record created successfully!', 'Created Successfully!');
          this.activeModal.close('success');
        } else {
          this.handleErrorsFromServer(result);
        }
      },
      error => {
        this.errorMessages = error.error.error_messages;
      },
      complete => {
        this.loading = false;
      }

    );
  }
  private saveChanges(): any {
    // this.form.value.account_status = this.form.value.account_status === true ? 1 : 0;
    this.form.value.user_id = this.formData.id;
    this._httpService.post('users/update', this.form.value).subscribe(
      result => {
        if (result.response.response_status.response_code === 200) {
          this.toastrService.success('Record created successfully!', 'Created Successfully!');
          this.activeModal.close('success');
        } else {
          this.handleErrorsFromServer(result);
        }
      },
      error => {
        this.errorMessages = error.error.error_messages;
      },
      complete => {
        this.loading = false;
      }

    );
  }

  public handleErrorsFromServer(response: any) {
    this.loading = false;
    this.hasErrors = true;
    this.errorMessages = [];
    Object.entries(response.response.error).forEach(
      ([key, value]) => // console.log(key, value)
        this.errorMessages.push(value)
    );
  }


  public closeModal(): void {
    this.activeModal.dismiss('Cross click');
  }
}
