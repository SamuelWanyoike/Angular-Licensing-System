import { NgModule } from '@angular/core';
import { ModalModule } from 'ngx-bootstrap/modal';
import { SharedModule } from '../shared/shared.module';
import { DevelopersRoutingModule } from './developers-routing';
import { ListDevelopersComponent } from './manage-developers/list-developers/list-developers.component';
import { AddDeveloperComponent } from './manage-developers/add-developer/add-developer.component';

@NgModule({
  imports: [
    SharedModule,
    DevelopersRoutingModule,
    ModalModule.forRoot(),
  ],
  declarations: [
  ListDevelopersComponent,
  AddDeveloperComponent],
  entryComponents: [
    AddDeveloperComponent
  ],
})
export class DevelopersModule { }

