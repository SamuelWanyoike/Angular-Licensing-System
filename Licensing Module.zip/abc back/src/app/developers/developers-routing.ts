import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListDevelopersComponent } from './manage-developers/list-developers/list-developers.component';
import { AuthGuard } from '../shared/services/auth.guard';
const routes: Routes = [
    {
        path: 'list',
        component: ListDevelopersComponent,
        canActivate: [AuthGuard],
        data: {
            title: 'Developers List',
            
        }
    }
];

export const DevelopersRoutingModule: ModuleWithProviders = RouterModule.forChild(routes);

       