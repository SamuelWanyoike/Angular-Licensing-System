import { NgModule } from '@angular/core';
import { ModalModule } from 'ngx-bootstrap/modal';
import { SharedModule } from '../shared/shared.module';

import { BillsRoutingModule } from './bills-routing';
import { ListBillsComponent } from './list-bills/list-bills.component';

@NgModule({
  imports: [
    SharedModule,
    BillsRoutingModule,
    ModalModule.forRoot(),
  ],
  declarations: [
  ListBillsComponent
  ],
  entryComponents: [
    ListBillsComponent
  ],
})
export class BillsModule { }

