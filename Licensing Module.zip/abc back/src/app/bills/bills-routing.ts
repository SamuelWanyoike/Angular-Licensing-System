import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../shared/services/auth.guard';
import { ListBillsComponent } from './list-bills/list-bills.component';
const routes: Routes = [
    {
        path: 'list',
        component: ListBillsComponent,
        data: {
            title: 'Bills List',
            
        }
    }
];

export const BillsRoutingModule: ModuleWithProviders = RouterModule.forChild(routes);

       