import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, ValidatorFn } from '@angular/forms';
@Component({
  selector: 'app-list-bills',
  templateUrl: './list-bills.component.html',
  styleUrls: ['./list-bills.component.scss']
})
export class ListBillsComponent implements OnInit {
demoForm: FormGroup;
   
   arrayItems: {
     id: number;
     title: string;
   }[];
   constructor(private _formBuilder: FormBuilder) {
      this.demoForm = this._formBuilder.group({
         demoArray: this._formBuilder.array([],this.minSelectedCheckboxes())
      });
   }
   ngOnInit() {
     this.arrayItems = [];
   }

   get demoArray() {
    return this.demoForm.get('demoArray') as FormArray;
 }
 addItem(item) {
    this.arrayItems.push(item);
    this.demoArray.push(this._formBuilder.control(false));
 }
 removeItem() {
    this.arrayItems.pop();
    this.demoArray.removeAt(this.demoArray.length - 1);
 }
 minSelectedCheckboxes(): ValidatorFn {
    const validator: ValidatorFn = (formArray: FormArray) => {
    
       const selectedCount = formArray.controls
          .map(control => control.value)
          .reduce((prev, next) => next ? prev + next : prev, 0);
       
       return selectedCount >= 1 ? null : { notSelected: true };
    };
 
    return validator;
 }
}