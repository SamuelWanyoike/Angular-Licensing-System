
// tslint:disable-next-line:max-line-length

import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CountriesListComponent } from './countries/countries-list/countries-list.component';

const routes: Routes = [
    {
        path: 'countries',
        component: CountriesListComponent,
        data: {
            breadcrumb: 'Countries',
            title: 'Countries'
        }
    },
    
];

export const ConfigsRoutingModule: ModuleWithProviders = RouterModule.forChild(routes);
