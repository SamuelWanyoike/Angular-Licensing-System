export class Country {
  active: boolean;
  country_code: string;
  country_name: string;
  description: string;
  dialing_code: string;
}
