import { NgModule } from '@angular/core';
import { ModalModule } from 'ngx-bootstrap/modal';
import { ConfigsRoutingModule } from './configs-routing';
import { SharedModule } from '../shared/shared.module';
import { CountriesListComponent } from './countries/countries-list/countries-list.component';
import { AddCountryComponent } from './countries/add-country/add-country.component';
@NgModule({
  imports: [
    SharedModule,
    ConfigsRoutingModule,
    ModalModule.forRoot(),
  ],
  declarations: [
    CountriesListComponent,
    AddCountryComponent,
   
  ],
  entryComponents: [
    AddCountryComponent,
  ],
})
export class ConfigsModule { }

