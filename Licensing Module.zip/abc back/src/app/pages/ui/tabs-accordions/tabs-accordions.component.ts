import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-tabs-accordions',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './tabs-accordions.component.html',
  styleUrls: ['./tabs-accordions.component.scss']
})
export class TabsAccordionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
