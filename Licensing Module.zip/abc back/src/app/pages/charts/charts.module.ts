import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { DirectivesModule } from '../../theme/directives/directives.module';
import { BarComponent } from './bar/bar.component';
import { PieComponent } from './pie/pie.component';



export const routes = [
  { path: '', redirectTo: 'bar', pathMatch: 'full'},
  { path: 'bar', component: BarComponent, data: { breadcrumb: 'Bar Charts' } },
  { path: 'pie', component: PieComponent, data: { breadcrumb: 'Pie Charts' } },
  
];

@NgModule({
  imports: [
    CommonModule,
    NgxChartsModule,
    DirectivesModule,
    ChartsModule,
    ChartsModule,
    RouterModule.forChild(routes)
  ],
  declarations: [
    BarComponent,
    PieComponent,
   
  ]
})
export class ChartsModule { }
