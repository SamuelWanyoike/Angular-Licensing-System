import { Component, ViewEncapsulation } from '@angular/core';
// import { single } from './../charts.data';
import { HttpService } from 'src/app/shared/services/http.service';



 
@Component({
  selector: 'app-pie',
  templateUrl: './pie.component.html',
  encapsulation: ViewEncapsulation.None
})
export class PieComponent {
  dataSet: {};
 
  public multi: any[];
  public single: any[];
 
  public showLegend = true;
  public gradient = true;
  public colorScheme = {
    domain: ['#2F3E9E', '#D22E2E', '#378D3B', '#0096A6', '#F47B00', '#606060']
  }; 
  public showLabels = true;
  public explodeSlices = false;
  public doughnut = false;
  public countries: any;
  public dashboard: any;
  

  constructor(private _httpService: HttpService,) {

   this.loadDashboard();
  }
  
  private loadDashboard() {
    this._httpService.get('dashboard/analysis').subscribe(
      result => {
        if (result.response.response_status.response_code === 200) {
          this.dataSet = result.response.data;
          this.single = [
            {
              name: 'Active Licences',
              value: this.dataSet['active_licenses']
            },
            {
              name: 'Expired Licences',
              value: this.dataSet['expired_licenses']
            }
          ];
          console.log(this.single);

        } else {
        }
      },
      error => {
      },
      complete => {
      }
    );
   }
 
  
  public onSelect(event) {
    console.log(event);
  }
    
      ngOnInit(){
       
      }
}
