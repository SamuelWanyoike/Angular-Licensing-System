export interface Data {
    Active_licences: String;
    Expired_licences: Number;
  }