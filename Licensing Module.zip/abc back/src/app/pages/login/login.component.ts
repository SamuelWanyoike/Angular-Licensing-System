import { HttpService } from 'src/app/shared/services/http.service';
import { Component, ViewEncapsulation, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, AbstractControl, FormBuilder, Validators } from '@angular/forms';
import { CustomValidators } from 'ng2-validation';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class LoginComponent implements AfterViewInit {
    public _loginForm: FormGroup;
    public _formErrors: any;
    public _submitted = false;
    public _errorMessage = '';
    public router: Router;
    public form: FormGroup;
    public email: AbstractControl;
    public username: AbstractControl;
    public password: AbstractControl;

    constructor(router: Router, fb: FormBuilder, private _httpService: HttpService, private _router: Router) {
        this.router = router;
        this.form = fb.group({
                'email': ['', Validators.compose([Validators.required, CustomValidators.email])],
          //  'username': ['', Validators.compose([Validators.required])],
            'password': ['', Validators.compose([Validators.required, Validators.minLength(4)])]
        });

        this.email = this.form.controls['email'];
       // this.username = this.form.controls['username'];
        this.password = this.form.controls['password'];
    }

    public onSubmit(elementValues: Object): void {
        if (this.form.valid) {
            this._submitted = true;
            this._httpService.login('users/login', elementValues).subscribe(
                result => {
                    if (result.response.response_status.response_code === 200) {
                        localStorage.setItem('ls-token', result.response.data.access_token);
                        localStorage.setItem('permissions', JSON.stringify(result.response.data.permissions));
                        this.router.navigate(['/']);
                    } else {
                        this._errorMessage = result.response.response_status.response_description;
                    }
                },
                error => {
                    this._errorMessage = 'Server Error';
                    this._submitted = false;
                }
            );
        }
    }

    ngAfterViewInit(): void {
        document.getElementById('preloader').classList.add('hide');
    }

}
