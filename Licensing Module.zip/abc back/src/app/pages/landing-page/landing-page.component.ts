import { Menu } from './../../theme/components/menu/menu.model';
import { Component, OnInit, AfterViewInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class LandingPageComponent implements OnInit, AfterViewInit {
public menuItems = [
  new Menu(1, 'Dashboard', '/', null, 'tachometer', null, false, 0),
  // new Menu(999, 'Pests Master', '/pests/list', null, 'bug', null, false, 0),
  new Menu(1000, 'Pests', null, null, 'bug', null, true, 0),
  new Menu(1002, 'Master', '/pests/master', null, 'bug', null, false, 1000),
  new Menu(1003, 'Pest Countries', '/pests/pest-countries', null, 'bug', null, false, 1000),
  new Menu(1001, 'Configs', null, null, 'cogs', null, true, 1000),
  new Menu(10011, 'Life Forms', '/pests/configs/life-forms', null, 'th-list', null, false, 1001),
  new Menu(10012, 'Distribution Status', '/pests/configs/distribution-status', null, 'th-list', null, false, 1001),
  new Menu(10013, 'Control & Mgmt Status', '/pests/configs/control-status', null, 'th-list', null, false, 1001),
];
  constructor(router: Router) {
  }


  ngOnInit() {
  }
  ngAfterViewInit() {
    document.getElementById('preloader').classList.add('hide');
}
}
