import { HttpService } from 'src/app/shared/services/http.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-number-card-chart',
  templateUrl: './number-card-chart.component.html',
  styleUrls: ['./number-card-chart.component.scss']
})
export class NumberCardChartComponent implements OnInit {
  public patientsData;
  public visitsData;
  constructor(private _httpService: HttpService) { }
  public sales = [{ name: 'sales', value: 0.81, extra: { format: 'percent' } }];
  public salesBgColor = { domain: ['#2F3E9E'] };

  public likes = [{ name: 'likes', value: 47588 }];
  public likesBgColor = { domain: ['#D22E2E'] };

  public downloads = [{ name: 'Closed Visits', value: 0 }];
  public downloadsBgColor = { domain: ['#378D3B'] };

  public profit = [{ name: 'profit', value: 52470, extra: { format: 'currency' } }];
  public profitBgColor = { domain: ['#0096A6'] };

  public messages = [{ name: 'messages', value: 75296 }];
  public messagesBgColor = { domain: ['#606060'] };

  public patients = [{ name: 'Patients', value: 0 }];
  public patientsBgColor = { domain: ['#F47B00'] };

  public visits = [{ name: 'All Visits', value: 0 }];
  public visitsBgColor = { domain: ['#2F3E9E'] };
  ngOnInit() {
    this.loadPatients();
    this.loadVisits();
  }
  private loadPatients(): void {
    this._httpService.get('patients').subscribe(
      result => {
        if (result.response_code === 200) {
          this.patientsData = result.data.map(obj => {
            obj.name = obj.first_name + ' ' + obj.middle_name + ' ' + obj.surname;
            return obj;
          });
        } else {
        }
      },
      error => {
      },
      complete => {
        this.patients = [{ name: 'Patients', value: this.patientsData.length }];
      }

    );
  }
  private loadVisits(): void {
    this._httpService.get('visits').subscribe(
      result => {
        if (result.response_code === 200) {
          this.visitsData = result.data.map(obj => {
            return obj;
          });
        } else {
        }
      },
      error => {
      },
      complete => {
        const visitsCount = this.visitsData.length;
        this.visits = [{ name: 'All Visits', value: visitsCount }];
        const activeVisits = this.visitsData.filter((rec, index) => {
          return Number(rec.status) === 1;
        }).length;
        const closedVisits = this.visitsData.filter((rec, index) => {
          return Number(rec.status) === 2;
        }).length;
        this.downloads = [{ name: 'Closed Visits', value: closedVisits }];
        this.likes = [{ name: 'Active Visits', value: activeVisits }];
      }
    );
  }
  public infoLabelFormat(c): string {
    switch (c.data.name) {
      case 'sales':
        return `<i class="fa fa-shopping-cart mr-2"></i>${c.label}`;
      case 'likes':
        return `<i class="fa fa-thumbs-o-up mr-2"></i>${c.label}`;
      case 'downloads':
        return `<i class="fa fa-download mr-2"></i>${c.label}`;
      case 'profit':
        return `<i class="fa fa-money mr-2"></i>${c.label}`;
      case 'messages':
        return `<i class="fa fa-comment-o mr-2"></i>${c.label}`;
      case 'Patients':
        return `<i class="fa fa-users mr-2"></i>${c.label}`;
      case 'All Visits':
        return `<i class="fa fa-users mr-2"></i>${c.label}`;
      case 'Active Visits':
        return `<i class="fa fa-check mr-2"></i>${c.label}`;
      case 'Closed Visits':
        return `<i class="fa fa-stop mr-2"></i>${c.label}`;
      default:
        return c.label;
    }
  }

  public infoValueFormat(c): string {
    switch (c.data.extra ? c.data.extra.format : '') {
      case 'currency':
        return `\$${Math.round(c.value).toLocaleString()}`;
      case 'percent':
        return `${Math.round(c.value * 100)}%`;
      default:
        return c.value.toLocaleString();
    }
  }

}
