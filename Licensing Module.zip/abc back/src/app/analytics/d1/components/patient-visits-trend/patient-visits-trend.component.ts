import { GlobalService } from './../../../../shared/services/global.service';
import { HttpService } from './../../../../shared/services/http.service';
import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';

@Component({
  selector: 'app-patient-visits-trend',
  templateUrl: './patient-visits-trend.component.html',
  styleUrls: ['./patient-visits-trend.component.scss']
})
export class PatientVisitsTrendComponent implements OnInit {
  public visitDates: any = [];
  public isLoaded = false;
  graphData: any[] = [];
  view: any[] = [630, 400];

  // options
  showXAxis = true;
  showYAxis = true;
  gradient = false;
  showLegend = false;
  showXAxisLabel = true;
  xAxisLabel = 'Date of Visit';
  showYAxisLabel = true;
  yAxisLabel = 'No. of Visits';

  colorScheme = {
    domain: ['#5AA454']
  };

  constructor(private _httpService: HttpService, private _globalService: GlobalService) {
  }
  ngOnInit(): void {
    this.loadData();
  }
  loadData(): void {
    this._httpService.get('visits').subscribe(
      result => {
        if (result.response_code === 200) {
          this.visitDates = result.data.map(obj => {
            return moment(obj.check_in).format('YYYY-MM-DD');
          });
        } else {
        }
      },
      error => {
      },
      complete => {
        const labels = this._globalService.enumerateDaysBetweenDates('20190420', '20190427');
        labels.forEach(label => {
          let b = new Object({name: label, value: 0});
          let tCount = 0;
          this.visitDates.forEach(vDate => {
            if (label === vDate) {
              tCount = tCount + 1;
            }
            b = new Object({name: label, value: tCount});
          });
          this.graphData.push(b);
        });
        this.isLoaded = true;
      });
  }
  onSelect(event) {
    console.log(event);
  }
}
