import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { D1Component } from './d1/d1/d1.component';
import { CustomersListComponent } from '../customers/customers-list/customers-list.component';
import { ListBillsComponent } from '../bills/list-bills/list-bills.component';
const routes: Routes = [
    {
        path: '',
        component: D1Component,
        data: {
            breadcrumb: 'Dashboard',
            title: 'Dashboard'
        }
    },
    {
        path: 'list',
        component: CustomersListComponent,
        data: {
            title: 'Customers List',
        },
        
    
    },
    {
        path: 'list',
        component: ListBillsComponent,
        data: {
            title: 'Bills List',
        },
        
    
    },
    // {
    //     path: ':id',
    //     component: ViewClientComponent,
    //     data: {
    //         breadcrumb: 'View Client',
    //         title: 'Client'
    //     }
    // },
];

export const AnalyticsRoutingModule: ModuleWithProviders = RouterModule.forChild(routes);
