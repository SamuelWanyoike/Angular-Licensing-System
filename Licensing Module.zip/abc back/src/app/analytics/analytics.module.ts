import { AnalyticsRoutingModule } from './analytics-routing';
import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';
import { D1Component } from './d1/d1/d1.component';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { BarComponent } from '../pages/charts/bar/bar.component';
import { PieComponent } from '../pages/charts/pie/pie.component';

import { CustomersListComponent } from '../customers/customers-list/customers-list.component';
import { AddCustomerComponent } from '../customers/add-customer/add-customer.component';
import { ViewCustomerComponent } from '../customers/view-customer/view-customer.component';
import { ListBillsComponent } from '../bills/list-bills/list-bills.component';
import { BillsModule } from '../Bills/bills.module';


@NgModule({
  imports: [
    SharedModule,
    AnalyticsRoutingModule,
    NgxChartsModule,
    BillsModule
  
  ],
  declarations: [
   D1Component,
   CustomersListComponent,
   AddCustomerComponent,
   ViewCustomerComponent,
   
   
  
  ],
  entryComponents: [
    AddCustomerComponent,
   
  ],
})
export class AnalyticsModule { }

