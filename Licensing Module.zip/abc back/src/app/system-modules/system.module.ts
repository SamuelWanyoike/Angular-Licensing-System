import { NgModule } from '@angular/core';
import { ModalModule } from 'ngx-bootstrap/modal';
import { SystemModulesRoutingModule } from './system-routing';
import { SharedModule } from '../shared/shared.module';
import { ListSystemModulesComponent } from './manage-modules/list-system-modules/list-system-modules.component';
import { AddSystemModuleComponent } from './manage-modules/add-system-module/add-system-module.component';

@NgModule({
  imports: [
    SharedModule,
    SystemModulesRoutingModule,
    ModalModule.forRoot(),
  ],
  declarations: [

  ListSystemModulesComponent,

  AddSystemModuleComponent],
  entryComponents: [
    AddSystemModuleComponent

  ],
})
export class SystemModulesModule { }

