import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListSystemModulesComponent } from './manage-modules/list-system-modules/list-system-modules.component';
const routes: Routes = [
    {
        path: 'list',
       component: ListSystemModulesComponent,
        data: {
            title: 'System Modules'
        }
    }
];

export const SystemModulesRoutingModule: ModuleWithProviders = RouterModule.forChild(routes);
