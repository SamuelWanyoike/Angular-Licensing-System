import { Menu } from './menu.model';

export const verticalMenuItems = [
    new Menu(1, 'Dashboard', '/', null, 'tachometer', null, false, 0),
    new Menu(6000, 'Users Management', null, null, 'users', null, true, 0),
    new Menu(6001, 'Users', '/users/list', null, 'th-list', null, false, 6000),
    new Menu(6001, 'User Roles Management', '/users/roleList', null, 'th-list', null, false, 6000),
    new Menu(6002, 'Bills Management', '/bills/list', null, 'users', null, false, 0),
  
];

export const horizontalMenuItems = [
  new Menu(1, 'Dashboard', '/', null, 'tachometer', null, false, 0), 
  new Menu(6000, 'Users Management', null, null, 'users', null, true, 0),
  new Menu(6001, 'Users', '/users/list', null, 'th-list', null, false, 6000),
  new Menu(6001, 'User Roles Management', '/users/roleList', null, 'th-list', null, false, 6000),
  new Menu(6002, 'Bills Management','/bills/list', null, 'users', null, false, 0),

 ];
