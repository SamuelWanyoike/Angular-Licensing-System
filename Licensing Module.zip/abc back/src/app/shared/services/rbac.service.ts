import { Injectable } from '@angular/core';
import { HttpService } from 'src/app/shared/services/http.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class RbacService {
  permissions: any;
  roles: any;

  constructor(private _httpService: HttpService, private http: HttpClient) { 
    this.permissions = localStorage.getItem('permissions');
  }

  public hasPriveledge(priveledge: string): boolean {
    this.permissions = localStorage.getItem('permissions');
    return this.permissions.indexOf(priveledge) > -1 ? true : false;
  }
  setRoles(){
    this.roles = localStorage.setItem('roles','')  
  }

  getAllRoles() {
    var reqHeader = new HttpHeaders({ 'No-Auth': 'True' });
    this.permissions = localStorage.getItem('permissions')
    return this.http.get('roles/show', { headers: reqHeader });
  }

// roles:any;
// constructor(private _httpService: HttpService,) {
//  }
//  public setRoles(roles:any){
//   localStorage.removeItem('roles');
//   localStorage.setItem('roles',roles);
//  }
//  public getRoles():any{
//   this._httpService.get('roles/show', { headers: HttpHeaders });
//   if(localStorage.getItem('roles')=='undefined'){
//     return null;
//   }else{
//     return JSON.parse(localStorage.getItem('roles'));
//   }
//  }

//  public removeRoles(){
//   return localStorage.removeItem('roles');
// }
 public canGetAccess(role:string): boolean{
   if(localStorage.getItem('permissions')=='undefined'){
     return false;
   }else{
     this.roles=JSON.parse(localStorage.getItem('permissions'));
     this.roles=this.roles[0].Roles;
    if(this.roles.includes(role)){
       return true;
     }
     return false;
    
   }
 }

//  roleMatch(allowedRoles): boolean {
//   var isMatch = false;
//   var userRoles: string[] = JSON.parse(localStorage.getItem('roles'));
//   allowedRoles.forEach(element => {
//     if (userRoles.indexOf(element) > -1) {
//       isMatch = true;
//       return false;
//     }
//   });
//   return isMatch;

// }
// }

}
